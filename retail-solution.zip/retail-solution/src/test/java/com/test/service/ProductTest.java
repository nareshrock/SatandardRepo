package com.test.service;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.retail.model.Product;
import com.retail.service.ProductService;

import junit.framework.TestCase;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"classpath:application-context.xml"})
public class ProductTest extends TestCase {
	
	@Autowired
	private ProductService productService;

	@Before
	public void beforTest(){
	
	}
	
	@Test
	public void testPrintTotalBill(){
		
		List<Product> products = productService.getCartItems();
		assertNotNull(products);
		assertTrue(products.size()> 0);
		System.out.println("Detail Ietemized bill");
		
		for(Product item : products){
			System.out.println("Product Name: " + item.getProductName() + ", Cost:" + item.getAmount() 
					+ ", Sales Tax:" + productService.calcSalesTaxForProduct(item));
		}
		
		System.out.println("Total Cost:" + productService.calculateTotalCost(products));
		System.out.println("Toatl Sales Tax:" + productService.calculateTotalSalesTax(products));
		
	}
}
