package com.retail.model;

import java.io.Serializable;


/**Entity class representing Product object. It has been created as POJO but
 * in actual it should use JPA annotations to map to db table
 * @author Naresh
 *
 */
public class Product implements Serializable{
	
	private static final long serialVersionUID = 1472834256035143789L;

	private long id;
	private String productName;
	private String category;
	private double amount;
	
	public Product(){
		
	}

	public Product(long id, String productName, String category, double amount) {
		this.id = id;
		this.productName = productName;
		this.category = category;
		this.setAmount(amount);
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}
	
	
}
