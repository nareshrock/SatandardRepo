package com.retail.dao;

import java.util.List;

import com.retail.model.Product;

/** DAO API for product entity. In actual it should interact with database to carry out CRUD operations.
 * For this assignment will use hard coded values.
 * @author Naresh 
 *
 */
public interface ProductDao {

	/** load some products
	 * @return List of Products
	 */
	public List<Product> findProducts();
	
}
