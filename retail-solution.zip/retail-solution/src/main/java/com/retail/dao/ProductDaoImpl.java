package com.retail.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.retail.model.Product;

@Repository
public class ProductDaoImpl implements ProductDao{
	
	private static List<Product> products;

	@Override
	public List<Product> findProducts() {
		
		return createProducts();
	}

	public static List<Product> createProducts() {
		products = new ArrayList<Product>();
		String category=null;
		double amount;
		for(int i=1; i<11; i++){
			 category = (i % 3==1) ? "A" : (i % 3==2) ? "B" : "C";
			 amount =  i * 100;
			 products.add(new Product(i, "P" +i, category, amount));
			
		}
		return products;
		
	}
	
}
