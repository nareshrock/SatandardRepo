package com.retail.service;

import java.util.List;

import com.retail.model.Product;

/** This service class holds API for product functions such as generateTotalBill, tax etc.
 * @author Naresh
 *
 */
public interface ProductService {

	/**sum cost of products passed in arguments
	 * @param products
	 * @return totalCost
	 */
	public double calculateTotalCost(List<Product> products);
	
	
	/** sum sales tax amount of products passed in parameter. Sales tax cost will be vary by product
	 * category.
	 * @param products
	 * @return totalSalesTax
	 */
	public double calculateTotalSalesTax(List<Product> products);
	
	
	/**Find the product list
	 * @return
	 */
	public List<Product> getCartItems();
	
	/** calculate sales tax for each product as per category
	 * @param product
	 * @return
	 */
	public double calcSalesTaxForProduct(Product product);
	
}
