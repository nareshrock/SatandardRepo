package com.retail.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.retail.dao.ProductDao;
import com.retail.model.Product;

@Service
public class ProductServiceImpl implements ProductService{

	@Autowired
	private ProductDao productDao;
	
	@Override
	public double calculateTotalCost(List<Product> products) {
		double sum=0.0;
		for(Product item : products){
			sum = sum + item.getAmount();
			
		}
		return sum;
	}

	@Override
	public double calculateTotalSalesTax(List<Product> products) {
		double totalTax=0;
		
		for(Product item : products){
			
			totalTax += calcSalesTax(item);
		}
		return totalTax;
	}

	@Override
	public List<Product> getCartItems() {
		
		return productDao.findProducts();
	}
	
	@Override
	public double calcSalesTaxForProduct(Product item){
		
		return calcSalesTax(item);
	}
	
	private double calcSalesTax(Product item){
		double totalTax=0;
		
		if("A".equals(item.getCategory())){
			totalTax += item.getAmount() * ((double)10/100);
		}else if("B".equals(item.getCategory())){
			totalTax += item.getAmount() * ((double)20/100);
		}else{
			totalTax += 0;
		}
		
		return totalTax;
	}

}
